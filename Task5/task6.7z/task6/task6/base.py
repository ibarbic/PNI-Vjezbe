#!C:\Python27\python.exe

def start_html():
    print ("""Content-type:text/html\r\n\r\n
    <html>
    <body>""")

def finish_html():
    print ("""</body>
    </html>""")

